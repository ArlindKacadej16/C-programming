/*
CH-230-A
a1 p3.[c or cpp or h]
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>

int main(){
	float result; /*The result of the calculation*/
	int a = 5;
	float b = 13.5; /*13.5 is a decimal number. Therefore it is a float data type rather than int*/
	result = a / b;
	printf("The result is %f\n", result); /*result is a float => we should use %f as a formatting specification rather than %d*/
	return 0;
}

