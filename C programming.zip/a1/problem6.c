/*
CH-230-A
a1 p6.[c or cpp or h]
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
int main() {  
    char c = 'F';
    int second_ASCII= (int) c + 3; //int second_ASCII is set equal to the value of char c ASCII added to 3
    printf("%c , %d\n", second_ASCII, second_ASCII);// %d displays the integer value of the second character (ASCII code)
    // %c displays the actual character
}