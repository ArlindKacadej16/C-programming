/*
CH-230-A
a1 p4.[c or cpp or h]
Arlind Kacadej
akacadej@jacobs-university.de
*/#include <stdio.h>

int main(){
    int x = 17;
    int y = 4;
    printf("x=%d\n", x);
    printf("y=%d\n", y);
    int sum = x + y;
    printf("sum=%d\n", sum);
    int product = x * y;
    printf("product=%d\n", product);
    int difference = x - y; /*Computes the difference x - y*/
    printf("difference=%d\n", difference);
    float division = (float) x / y; /*Computes the division x / y and I added "(float)" in order to get a float out of the division*/
    printf("division=%f\n", division); //Only two digits after decimal point appear 
    int remainder = x % y; /*Computes the remainder of the division x / y*/
    printf("remainder of division=%d\n", remainder);
}