#include <stdio.h>

int main(){
	int result; /*The result is out of calculation*/
	result = (2 + 7) * 9 / 3;
	printf("The result is %d\n", result); /*This happened because we didn't
	put result as an input inside the printf statement*/
	return 0;
}

