#include <stdio.h>
int main() {  
    char c = 'F';
    // %d displays the integer value of a character
    // %c displays the actual character
    int p2= (int) c;
    
}