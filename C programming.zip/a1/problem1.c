#include <stdio.h>

int main(){
    double result; /*The result of our calculation*/
    result = (3+1)/5.0; /*I susbstituted 5 with 5.00 - while dividing by 5, an integer, 
    you can't get a decimal number (float), when you divide by 5.00 (a float) you turn the result into a float too*/
	printf("The value of 4/5 is %fl\n",result);
}
