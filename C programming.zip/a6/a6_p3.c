/*
CH-230-A
a6_p3.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
#define MIN(A, B, C, MIN) {\
                    if(A<B && A<C){\
                        MIN = A;\
                    }else if(B<A && B<C){\
                        MIN = B;\
                    }else{\
                        MIN = C;\
                    };\
                    ;}
//Macro assigns the min value among A, B, and C to MIN

#define MAX(A, B, C, MAX) {\
                    if(A>B && A>C){\
                        MAX = A;\
                    }else if(B>A && B>C){\
                        MAX = B;\
                    }else{\
                        MAX = C;\
                    };\
                    ;}               
//Macro assigns the max value among A, B, and C to MAX

#define MIDRANGE(X,Y) {float midrange = (X+Y)/2;\
                    printf("The mid-range is: %f\n", midrange);}

int main(){
	float a, b, c, min, max;
    scanf("%f", &a);
    scanf("%f", &b);
    scanf("%f", &c);
    //Inputs taken
    MIN(a, b, c, min);
    MAX(a, b, c, max);
    MIDRANGE(min, max);
}