/*
CH-230-A
a6_p9.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
#include <stdlib.h>

struct list {
    int info;
    struct list * next; /* self reference */
};

struct list * my_list = NULL;

struct list * push_back ( struct list * my_list , int value ) {
    struct list * cursor , * newel ;
    cursor = my_list ;
    newel = ( struct list *) malloc ( sizeof ( struct list ));
    if ( newel == NULL ) {
        printf (" Error allocating memory \n");
        return my_list ;
    }
    newel -> info = value ;
    newel -> next = NULL ;
    if ( my_list == NULL )
        return newel ;
    while ( cursor -> next != NULL ){
        cursor = cursor -> next ;
        cursor -> next = newel ;
    }
    return my_list ;
} //Puts new element at the end of linked list

struct list * push_front (struct list * my_list, int value) {
    struct list * newel ;
    newel = ( struct list *) malloc ( sizeof ( struct list ));
    if ( newel == NULL ) {
    printf (" Error allocating memory \n");
    return my_list ;
    }

    newel -> info = value ;
    newel -> next = my_list ;
    return newel ;
} //Puts new element at the beginning of linked list

void remove_first(){
    struct list * ptr;
    ptr = my_list;
    my_list = my_list -> next;
    free(ptr);
} //Removes first element from linked list


int getCount(struct list * head) 
{ 
    int count = 0;  //Initialize count 
    struct list* current = head;  //Initialize current 
    while (current != NULL) { 
        count++; 
        current = current->next; 
    } 
    return count; 
} //Counts number of nodes in linked list

void newElement(){
    struct list *ptr, *temp;
    int i, index;
    
    temp = (struct list*) malloc(sizeof(struct list));
    //Dynamic allocation

    if(temp==NULL){
        exit(1);
    }

    scanf("%d", &index);
    scanf("%d", &temp->info) ;
  
    temp->next=NULL;
    if(index==0){
        temp->next=my_list;
        my_list=temp;
    }else if(index>getCount(my_list)){
        printf("Invalid position!\n");
    }else{
        for(i=0, ptr=my_list; i<index-1; i++) 
		{ 
			ptr=ptr->next;
			if(ptr==NULL){
            	exit(1);
            }
        }
        temp->next = ptr->next;
        ptr->next= temp;
    }
} //Puts new element at given index of linked list

static void reverse(struct list ** head_ref) 
{ 
    struct list* prev = NULL; 
    struct list* current = *head_ref; 
    struct list* next = NULL; 
    while (current != NULL) { 
        // Store next 
        next = current->next; 
        // Reverse current node's pointer 
        current->next = prev; 
        // Move pointers one position ahead. 
        prev = current; 
        current = next; 
    } 
    *head_ref = prev; 
} //Reverses linked list

void print_list (struct list * my_list) {
    struct list * p;
    for (p = my_list ; p; p = p-> next ) {
        printf ("%d ", p-> info );
    }
    printf("\n");
} //Prints linked list

void dispose_list (struct list * my_list) {
    struct list * nextelem ;
    while ( my_list != NULL ) {
        nextelem = my_list -> next ;
        free ( my_list );
        my_list = nextelem ;
    }
    exit(0);
} //Frees struct & exits

int main(){
    char c;
    int n;
    while(1){
        scanf("%c", &c); //Repeatedly takes character command
        switch(c){
            case 'a':
                scanf("%d", &n);
                my_list = push_back (my_list, n);
                break;
            case 'b':
                scanf("%d", &n);
                my_list = push_front (my_list, n);
                break;
            case 'r':
                if(my_list==NULL){
                    continue;
                }else{
                    remove_first();
                    break;
                }
            case 'p':
                print_list(my_list);
                break;
            case 'i':
                newElement();
                break;
            case 'R':
                reverse(&my_list);
                break;
            case 'q':
                dispose_list(my_list);
                break;
        }
    }
    printf("\n");
}