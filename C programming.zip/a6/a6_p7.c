/*
CH-230-A
a6_p7.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>

void set3bits(unsigned char c, int x, int y, int z){
    printf("After setting the bits: ");
    int i;
    for(i=7; i>=0; i--){
        if(i==x || i==y || i==z){ 
        //Checks if we're dealing with one of the requested positions 
            printf("1");
        }else{
            if((c>>i) & 1){
                printf("1"); 
            }else{
                printf("0");
            }
        }
    }
    printf("\n");
}

int main(){
	unsigned char c;
    int x, y, z;
    scanf("%c", &c); 
    scanf("%d", &x);
    scanf("%d", &y);
    scanf("%d", &z);
    //Inputs taken
    printf("The decimal representation is: %d\n", c);
    printf("The binary representation is: ");
    
    int i;
    for(i=7; i>=0; i--){
         if((c>>i) & 1){
             printf("1"); 
         }else{
             printf("0");
         }
    }
    printf("\n");

    set3bits(c, x, y, z); 
    //Function replaces bits and prints the modified form

    return 0;
}