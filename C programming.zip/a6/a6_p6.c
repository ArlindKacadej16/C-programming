/*
CH-230-A
a6_p6.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>

int main(){
	unsigned char c;
    scanf("%c", &c); //Takes input
    printf("The decimal represantation is: %d\n", c);
    printf("The binary represantation is: ");

    int i;
    for(i=7; i>=0; i--){ 
        //Looping through 8 positions of binary form
        if((c>>i) & 1){
            printf("1"); 
        }else{
            printf("0");
        }
    }
    printf("\n"); //Newline
    return 0;
}