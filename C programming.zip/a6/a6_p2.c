/*
CH-230-A
a6_p2.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
#define LEASTSIG(A) {unsigned char abit=A & 1;\
                    printf("%d\n", abit);}
//Macro gets least significant bit and prints it

int main(){
	unsigned char c;
    scanf("%c", &c); //Takes input
    printf("%d\n", c);
    LEASTSIG(c);
    return 0;
}