/*
CH-230-A
a6_p5.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>

unsigned int reverseBinary(unsigned char n) { 
    unsigned int NR_BITS = sizeof(n) * 8; //Allocating memory
    unsigned int reverse_binary = 0; 
    int i; 
    for (i = 0; i < NR_BITS; i++) { 
        if((n>>i) & 1){
           reverse_binary |= 1 << ((NR_BITS - 1) - i);   
    	}
	} 
    return reverse_binary; //returns the reverse binary
}

int main(){
	int i, temp;
	unsigned char c;
	unsigned int reverse_c;
	
	scanf("%c", &c);
	reverse_c= reverseBinary(c);
	
	printf("The decimal representation is: %d\n", c);
	printf("The backwards binary representation is: ");
	
	int counter = 0, j; //Counter var is needed for printing zeros
	for (i = 7; i >= 0; i--){
		temp = reverse_c >> i; //Shifts element on pos. i
   		if (temp & 1){
   			for(j=0; j<counter; j++){
   				printf("0");
			}
		counter=0;
		printf("1");
  		}else{
			counter++;
 		}
	}	
	printf("\n");
	return 0;
}