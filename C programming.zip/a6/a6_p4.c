/*
CH-230-A
a6_p4.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
#define INTERMEDIATE

int main(){
    int n;
    scanf("%d", &n); //Taking number of elements
    int numbers1[n];
    int numbers2[n];

    int i;
    for(i=0; i<n; i++){
        scanf("%d", &numbers1[i]); //Takes numbers as input
    }

    for(i=0; i<n; i++){
        scanf("%d", &numbers2[i]); //Takes numbers as input
    }
    
    int product[n], scalarProduct=0; 
    #ifdef INTERMEDIATE
    printf("The intermediate values are:\n"); 
    for(i=0; i<n; i++){ 
        product[i]=numbers1[i] * numbers2[i]; 
        printf("%d\n", product[i]); 
        scalarProduct= scalarProduct + product[i]; 
    } 
    printf("The scalar product is: %d\n", scalarProduct);
    #endif

    #ifndef INTERMEDIATE
    for(i=0; i<n; i++){ 
        product[i]=numbers1[i] * numbers2[i]; 
        scalarProduct= scalarProduct + product[i];
        printf("The scalar product is: %d\n", scalarProduct); 
    } 
    #endif //case when INTERMEDIATE is not defined
    
    return 0;
}