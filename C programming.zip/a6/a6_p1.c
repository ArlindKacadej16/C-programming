/*
CH-230-A
a6_p1.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
#define SWAP(x, y, TYPE) {TYPE temp = x; \
                        x = y; y = temp; \
                        } 
 
int main(){
    int a, b;
    double x, y;
    scanf("%d", &a);
    scanf("%d", &b);
    scanf("%lf", &x);
    scanf("%lf", &y);
    //Inputs taken
    SWAP(a, b, int);
    SWAP(x, y, double);
    //Values swaped
    printf("After swapping:\n");
    printf("%d\n%d\n", a, b);
    printf("%.6lf\n%.6lf\n", x, y);
    //Swaped values printed
    return 0;
}