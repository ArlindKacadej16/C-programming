/*
CH-230-A
a2_p8.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
int main(){
    int a; //Declaration of the number
    scanf("%d", &a); //Taking input for a
    if(a%14==0){
        printf("The number is divisible by 2 and 7\n"); /*If a number is divisible by 14, that means that it 
        is divisible by both of its factors, 2 and 7*/
    }else{    
        printf("The number is NOT divisible by 2 and 7\n");
    }
}