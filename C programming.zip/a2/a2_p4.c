/*
CH-230-A
a2_p4.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
int main(){
    float a, b, h; //Declaration of variables
    scanf("%f\n", &a);
    scanf("%f\n", &b);
    scanf("%f", &h); 
    /*Input taken for the three of variables*/
    float square_area = a * a; //Computes the area of the square
    float rectangle_area = a * b; //Computes the area of the rectangle
    float triangle_area = a * h / 2; //Computes the area of the triangle
    float trapezoid_area =  (a + b) * h / 2; //Computes the area of the trapezoid

    printf("square area=%f\n", square_area);
    printf("rectangle area=%f\n", rectangle_area);
    printf("triangle area=%f\n", triangle_area);
    printf("trapezoid area=%f\n", trapezoid_area);
    /*The 4 printf statements printed the results*/
}