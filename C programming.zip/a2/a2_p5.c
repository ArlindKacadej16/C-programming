/*
CH-230-A
a2_p5.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
int main(){
    int a;
    printf("Enter the value of a: ");
    scanf("%d", &a);
    int *ptr_a = &a; //Declearing a pointer to a 
    printf("%p\n", ptr_a); //Printing the adress of a
    *ptr_a +=5; //Adding 5 to a through a pointer
  	printf("%d\n", *ptr_a);//Printing the updated value of a
  	printf("%p", ptr_a); //Printing the adress of a which actually should remain the same
}