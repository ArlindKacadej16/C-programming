/*
CH-230-A
a2_p9.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
int main(){
    char c;
    scanf("%c", &c); //Taking character input for c
    int ascii_c = (int) c; //Storing the ascii code of c into a variable
    if(ascii_c>47 && ascii_c<58){
        printf("%c is a digit\n", c); //The ascii values for digits 0..9 range from 48..57
    }
    else if((ascii_c>64 && ascii_c<91) || (ascii_c>96 && ascii_c<123)){
        printf("%c is a letter\n", c); //The ascii values for letters A..Z and a..z range from 65..90 and 97..122 respectively
    }
    else{
        printf("%c is some other symbol\n", c); //The ascii values for symbols are all the left ascii values from digits and letters
    }
}