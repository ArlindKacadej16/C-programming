/*
CH-230-A
a2_p3.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
int main(){
    int weeks, days, hours;
    printf("Enter the number of weeks: ");
    scanf("%d", &weeks); //Taking input for nr. of weeks
    printf("Enter the number of days: ");
    scanf("%d", &days); //Taking input for nr. of days
    printf("Enter the number of hours: ");
    scanf("%d", &hours); //Taking input for nr. of hours
    int total_hours = weeks * 24 * 7 + days * 24 + hours; //Computes the total number of hours
    printf("The total amount of hours is: %d\n", total_hours);
}