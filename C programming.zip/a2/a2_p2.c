/*
CH-230-A
a2_p2.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
int main(){
    char c;
    scanf("%c", &c);
    printf("character=%c\n", c);
    printf("decimal=%d\n", c);
    printf("octal=%o\n", c);
    printf("hexadecimal=%x\n", c);
}