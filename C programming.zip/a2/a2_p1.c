/*
CH-230-A
a2_p1.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
int main(){
    double a, b, sum_of_doubles, difference_of_doubles, square;
    int c, d, sum_of_integers, product_of_integers, sum_chars, prod_chars; //Last two variables are the sum and product of the chars inputed as a decimal values
    char e, f, sum, product; //The sum and product of the chars inputed as a char data type

    scanf(" %lf %lf", &a, &b);

    sum_of_doubles=a+b;
    difference_of_doubles=a-b;
    square=a*a; //The square of the first double

    printf("sum of doubles=%lf\n", sum_of_doubles);
    printf("difference of doubles=%lf\n", difference_of_doubles);
    printf("square=%lf\n", square);

    scanf(" %d %d", &c, &d);

    sum_of_integers=c+d;
    product_of_integers=c*d;

    printf("sum of integers=%d\n", sum_of_integers);
    printf("product of integers=%d\n", product_of_integers);

    scanf(" %c %c", &e, &f);

    sum_chars=e+f;
    prod_chars=e*f;
    sum=e+f;
    product=e*f;

    printf("sum of chars=%d\n", sum_chars);
    printf("product of chars=%d\n", prod_chars);
    printf("sum of chars=%c\n",sum);
    printf("product of chars=%c\n", product);
    
    return 0;
}