/*
CH-230-A
a2_p7.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
int main(){
    int i = 8;
    while (i >= 4){
        printf("i is %d\n", i);
        i--;
    }//The bracket type {} should have been put at the beginning and at the end of the while statement
    printf("That\'s it."); //I put \ before the quotation mark ' so that it could appear properly
    return 0;
}