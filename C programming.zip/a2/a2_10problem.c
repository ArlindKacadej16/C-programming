/*
CH-230-A
a2_10problem.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
#include <math.h>
int main(){
    int n;
    printf("Enter the value of n: ");
    scanf("%d", &n); //Takes input for n
    
	while(n<1){
		printf("Enter a positive value for n: ");
		scanf("%d", &n);
	} //Ensures that the user inputs a positive integer 
	
    int i =1 ;
    int hours;
    while(i<=n){
        hours = 24 * i; /*Computes the number of hours that have passed on the i-th day 
        i.e. 1st day = 24 * 1, 2nd day = 24 * 2 etc.*/
        if(i==1){  
            printf("1 day = %d hours\n", hours); //For the first day we write '1 day' instead of '1 days'
        }else{
            printf("%d days = %d hours\n", i, hours);
        } 
        i++; //Incrementment of i for each step by 1
    }
}
