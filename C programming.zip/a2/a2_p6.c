/*
CH-230-A
a2_p6.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
int main(){
    double x, y;
    printf("Enter x: ");
    scanf("%lf", &x);
    printf("Enter y: ");
    scanf("%lf", &y);
    double *ptr_one, *ptr_two, *ptr_three; //Declaration of the pointers
    ptr_one = &x;
    ptr_two = &x;
    ptr_three = &y;
    printf("%p\n", ptr_one); //Prints address of x through ptr_one
    printf("%p\n", ptr_two); //Prints address of x through ptr_two
    printf("%p\n", ptr_three);//Prints address of x through ptr_three
    /*The first and second adress must be the same, 
    while the third must be different.*/
}