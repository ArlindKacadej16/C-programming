/*
CH-230-A
a4_p1.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
#include <math.h>
double area(double r){
	double area1 = (r * r * M_PI);
    return area1;
}

double perimeter(double r){
    double perimeter1 = (2.0 * M_PI * r);
    return perimeter1;
}

int main(){
	double x, limit, change;
    scanf("%lf", &x);
    scanf("%lf", &limit);
    scanf("%lf", &change); /*If x is getting decremented => the input number
    for the value of [double change] should be negative*/
    double idx;
    //If x is getting incremented => idx+=. . . 
        for(idx = x; idx <= limit; idx += change){
            printf("%lf %lf %lf\n", idx, area(idx), perimeter(idx));
    }
}