/*
CH-230-A
a4_p1.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
#include <math.h>

int main(){
	float x, limit, change;
    scanf("%f", &x);
    scanf("%f", &limit);
    scanf("%f", &change); //Inputs taken
    float idx;
        for(idx = x; idx <= limit; idx += change){
            printf("%f %f %f\n", idx, idx * idx * M_PI, 2.0 * M_PI * idx);
            //Prints radius, area and perimeter
    }
}