/*
CH-230-A
a4_p9.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
#include <stdlib.h> 

int prodminmax(int arr[], int n){
    int largest=arr[0];
    int smallest=arr[1];
    int i;
    if(largest < smallest){
        int temp = largest;
        largest = smallest;
        smallest = temp;
    }

    for(i=0; i<n; i++){
            if(arr[i]>largest){
                largest=arr[i];
            }
        }

    for(i=0; i<n; i++){
            if(arr[i]<smallest){
                smallest=arr[i];
            }
        }
    
    int product = largest * smallest;
    return product;
}

int main(){
    int n, *ptr, i;
    printf("Enter the number of elements: \n");
    scanf("%d", &n);
    ptr = (int*)malloc(n * sizeof(int)); 
    
    if (ptr == NULL) { 
        printf("Memory not allocated.\n"); 
        exit(0); 
    } 
    else { 
  
        // Memory has been successfully allocated 
        printf("Memory successfully allocated using malloc.\n"); 
  
        // Get the elements of the array 
        for (i = 0; i < n; ++i) { 
            scanf("%d", &ptr[i]); 
    } 
    printf("%d\n", prodminmax(ptr, n));
    free(ptr); //Deallocating
    return 0;
    }
}