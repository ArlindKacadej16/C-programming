/*
CH-230-A
a4_p4.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
#include <string.h>
#define MAX_LIMIT 100

int count_consonants(char str[]){
    int i, counter = 0;
    for(i = 0; i < strlen(str); i++){
        int ascii = (int) str[i];
        if(((ascii>=65 && ascii <=90) || (ascii>=97 && ascii <=122)) 
        && (str[i] != 'a' && str[i] != 'e' && str[i] != 'i' 
        && str[i] != 'o' && str[i] != 'u' && str[i] != 'y' 
        && str[i] != ' ' && str[i] != '\n' && str[i] != 'A' 
        && str[i] != 'E' && str[i] != 'I' 
        && str[i] != 'O' && str[i] != 'U' && str[i] != 'Y')){
            counter += 1; 
            /*Increases the nr. of detected consonants 
            if the character is not a vowel, whitespace,
            symbol or endline*/
        }
    }
    return counter;
}

int main(){
    char string[MAX_LIMIT];
    while(1){ //Keeps the loop running until the 'break' command
        fgets(string, MAX_LIMIT, stdin);
        if(*string == '\n'){
            break;
            //Breaks the string when enter is pressed
        }else{
            printf("Number of consonants=%d\n", count_consonants(string));
        }
    }
    return 0;
}