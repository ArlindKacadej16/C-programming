/*
CH-230-A
a4_p11.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
int count_insensitive(char *str, char c){
    int i, counter=0;
    for(i=0; i<strlen(str); i++){
        if(str[i]==c || str[i]==tolower(c) || str[i]==toupper(c)){
            counter++;
        }
    }
    return counter;
}

int main() {
    char *ptr1, *ptr2;
    
    ptr1 = (char*)malloc(sizeof(char) * 50); 
    if (ptr1 == NULL) { 
        printf("Memory not allocated.\n"); 
        exit(1); 
    } 
    printf("Enter the string: ");
    fgets(ptr1, 50, stdin); //Getting input for string

    ptr2 = (char*)malloc(sizeof(char) * strlen(ptr1)); 
    if (ptr2 == NULL) { 
        printf("Memory not allocated.\n"); 
        exit(1); 
    } 
   
    strcpy(ptr2, ptr1); //Copying strings
    free(ptr1); //Deallocating
    printf("The character 'b' occurs %d times.\n",
    count_insensitive(ptr2, 'b'));
    printf("The character 'H' occurs %d times.\n",
    count_insensitive(ptr2, 'H'));
    printf("The character '8' occurs %d times.\n",
    count_insensitive(ptr2, '8'));
    printf("The character 'u' occurs %d times.\n",
    count_insensitive(ptr2, 'u'));
    printf("The character '$' occurs %d times.\n",
    count_insensitive(ptr2, '$'));

    free(ptr2);

    return 0;
}   
