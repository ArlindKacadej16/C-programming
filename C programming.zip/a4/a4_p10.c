/*
CH-230-A
a4_p10.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include<stdio.h>
#include <math.h>
void proddivpowinv(float a, float b, float *prod, float *div,
float *pwr, float *invb) {
   *prod = a * b;
   *div = a / b;
   *pwr = pow(a,b);
   *invb = 1/b; 
   printf("The product is: %f\n", *prod);
   printf("The division is: %f\n", *div);
   printf("The power is: %f\n", *pwr);
   printf("The inverse of b is: %f\n", *invb);
   //Values "returned"
}
int main() {
   float a, b;
   printf("Enter the values of the numbers: \n");
   scanf("%f", &a);
   scanf("%f", &b); //Inputs taken 
   float product, division, power, inverse;
   proddivpowinv(a, b, &product, &division, &power, &inverse);
   //Function executed
   return 0;
}