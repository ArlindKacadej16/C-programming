/*
CH-230-A
a4_p2.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
#include <string.h>
#define MAX_LIMIT 10000

int main(){
	char str[MAX_LIMIT];
    fgets(str, MAX_LIMIT, stdin); //Getting string input
    int idx;

    int length = strlen(str);

    for(idx=0; idx<length; idx++){
        if(str[idx]!= '\n' && str[idx] != '\0'){
            if((idx+2) % 2 == 0){ 
		//Even position characters are printed without space in front
                printf("%c\n", str[idx]);
            }else{
        //Odd position characters are printed with space in front
                printf(" %c\n", str[idx]);
            }
        }else{
            break;
        }
    }
}