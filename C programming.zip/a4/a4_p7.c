/*
CH-230-A
a4_p7.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
#include <stdlib.h> 

int main(){
    int n;
    scanf("%d", &n);
    int matrix[n][n]; //Declearing matrix
    int i, j;
    for(i=0; i<n; i++){
        for(j=0; j<n; j++){
            scanf("%d", &matrix[i][j]); //Taking elements
        }
    }

    printf("The entered matrix is:\n");
    for(i=0; i<n; i++){
        for(j=0; j<n; j++){
            printf("%d ",matrix[i][j]);
        }
        printf("\n");
    }
    
    printf("Under the main diagonal:\n");
    for(i=1; i<n; i++){ /*Elements under main diagonal 
    begin from the second row*/ 
        for(j=0; j<i; j++){
            printf("%d ",matrix[i][j]);
        }
    }
    printf("\n");
}