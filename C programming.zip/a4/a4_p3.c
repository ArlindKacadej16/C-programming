/*
CH-230-A
a4_p3.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
#include <math.h>

float geometric_mean(float arr[], int num);

float geometric_mean(float arr[], int num){
    float product = 1.0;
    int i;
    for(i = 0; i < num; i++){
        product *= arr[i];
    }
    float gm = pow(product, (float) 1/num); //Formula for geometric mean
    return gm;
}

float highest_number(float arr[], int num){
    float hn = arr[0];
    int i;
    for(i = 1; i < num; i++){
        if(arr[i] > hn){
            hn = arr[i]; 
            //Goes through all numbers to get the highest number
        }
    }
    return hn;
}

float smallest_number(float arr[], int num){
    float sn = arr[0];
    int i;
    for(i = 1; i < num; i++){
        if(arr[i] < sn){
            sn = arr[i];
            //Goes through all numbers to get the smallest number
        }
    }
    return sn;
}

float sum(float arr[], int num){
    float sum = 0;
    int i;
    for(i = 0; i < num; i++){
        sum += arr[i];
    }
    return sum;
}

int main(){
    float numbers[15];
    int idx;

    printf("Enter the elements of the array:\n");
    for(idx = 0; idx < 15; idx++){
        scanf("%f", &numbers[idx]); //Takes inputs for array nubers
        if(numbers[idx] < 0){
            break; //Stops input taking if a negative nr. is entered
        }
    }

    char command;
    printf("Enter the command: ");
    getchar();
    scanf("%c", &command); //Takes the character-command
    switch(command){
        case 'm':
            printf("%f\n", geometric_mean(numbers, idx));
            break;
        case 'h':
            printf("%f\n", highest_number(numbers, idx));
            break;
        case 'l':
            printf("%f\n", smallest_number(numbers, idx));
            break;
        case 's':
            printf("%f\n", sum(numbers, idx));
            break;
        default:
            printf("Invalid command.\n");
    }
}