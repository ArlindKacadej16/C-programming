/*
CH-230-A
a4_p6.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
#include <stdlib.h> 

void two_greatest(int numbers[], int n){
    int i, temp;
    int greatest_nr1 = numbers[0];
    int greatest_nr2 = numbers[1];
 
    if (greatest_nr1 < greatest_nr2)
    {
        temp = greatest_nr1;
        greatest_nr1 = greatest_nr2;
        greatest_nr2 = temp;
    }
 
    for (i = 2; i < n; i++)
    {
        if (numbers[i] > greatest_nr1)
        {
            greatest_nr2 = greatest_nr1;
            greatest_nr1 = numbers[i];
        }
        else if (numbers[i] >= greatest_nr2)
        {
            greatest_nr2 = numbers[i];
        }
    }
    printf("The largest number is: %d\n", greatest_nr1);
    printf("The second largest number is: %d\n", greatest_nr2);
}

int main(){
    int n, *ptr, i;
    printf("Enter the number of elements: \n");
    scanf("%d", &n);
    ptr = (int*)malloc(n * sizeof(int)); 
    
    if (ptr == NULL) { 
        printf("Memory not allocated.\n"); 
        exit(0); 
    } 
    else { 
  
        // Memory has been successfully allocated 
        printf("Memory successfully allocated using malloc.\n"); 
  
        // Get the elements of the array 
        for (i = 0; i < n; ++i) { 
            scanf("%d", &ptr[i]); 
    } 
    two_greatest(ptr, n);
    free(ptr); //Deallocating
    return 0;
    }
}