/*
CH-230-A
a4_p12.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
#include <ctype.h>
#include <string.h>

void replaceAll(char *str, char c, char e){
    int i;
    for(i=0; i<strlen(str); i++){
        if(str[i]==c){
            str[i]=e;
        }
    }
}

int main() {
    char string[80];
    char c, e;
    while(1){
        fgets(string, sizeof(string), stdin); 
        if(strcmp(string, "stop\n") == 0){
            break; //Breaks the loop if the string =="stop"
        }

        scanf("%c", &c);
        getchar();
        scanf("%c", &e);
        getchar();

        //Input for to be replaced and replacing character taken
        
        printf("Character to be replaced: %c\n", c);
        printf("Replacing character: %c\n", e);
        printf("String before replacement: %s", string);
        replaceAll(string, c, e); //Function replaces characters
        printf("String after replacement: %s\n", string);
    }
}