/*
CH-230-A
a8_p5.c
Arlind Kacadej
akacadej@jacobs-university.de
*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    //1
    FILE *filePointer, *fp;
    char ch, c1, c2;
    int i=0;
    //2
    filePointer = fopen("chars.txt", "r");
    // Opens the file where the chars are stored
    //3
    if (filePointer == NULL)
    {
        printf("File is not available \n");
    }
    else
    {
        //4
        while ((ch = fgetc(filePointer)) != EOF)
        {
            if(i==0){
                c1=ch;
                i++;
            }else if(i==1){
                c2=ch;
                break; 
            //Breaks after taking the second character from file
            }
        }
    }

    int codesum = (int) c1 + (int) c2;
    
    fp = fopen("codesum.txt", "w");

    fprintf(fp, "%d", codesum); 
    // Prints ASCII sum to file
    //5
    fclose(fp);

    return 0;
}