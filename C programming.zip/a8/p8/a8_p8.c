/*
CH-230-A
a8_p8.c
Arlind Kacadej
akacadej@jacobs-university.de
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX 20
int main()
{
    FILE *filePointer;
    char c, file1[MAX];
    int counter = 0, i = 0;
    fgets(file1, MAX, stdin);
    file1[strlen(file1)-1]='\0';

    filePointer = fopen(file1, "r");
    // Opens the file where the chars are stored
    if (filePointer == NULL){
        printf("File is not available \n");
        exit(1);
    }else{
        //4
        while ((c = fgetc(filePointer)) != EOF){
            if(c==' ' || c==','|| c=='?' || c=='!' ||
            c=='.' || c== '\t' || c=='\r' || c=='\n'){
                i++;
                if(i==1)
                    counter++; 
                    /*Increases the nr. of words when
                    the above character appear for the
                    first time*/ 
            }else{
                i = 0;
            }
        }
    }

    fscanf(filePointer, "%c", &c);

    printf("%d\n", counter);
    fclose(filePointer);

    return 0;
}