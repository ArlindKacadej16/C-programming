#include <stdio.h> 
#include <string.h>
#include <stdlib.h> // For exit() 
  
int main() { 
    int n, i, counter=0;
    scanf("%d", &n);
    FILE *fptr1, *fptr2; 
    char filename[20], buffer[64], c; 
    printf("Concating the content of 3 files ...\n");
    fptr2 = fopen("output.txt", "w"); 
    for(i=0; i<n; i++){
        scanf("%s", filename);
        fptr1 = fopen(filename, "r"); 
        if (fptr1 == NULL) { 
            printf("Cannot open file %s \n", filename); 
            exit(1); 
        }
        while (getc(fptr1) != EOF) { 
            counter++; 
        } 
        fseek(fptr1, 0, SEEK_SET);
        
        // Read contents from file  
        fread(buffer, 1, 64, fptr1);

        fwrite(buffer, counter, 1, fptr2);
        fputc('\n', fptr2);
        counter = 0;
        fclose(fptr1);  
    } 
    fclose(fptr2);

    fptr2 = fopen("output.txt", "r");
    while ((c= getc(fptr2)) != EOF) { 
        printf ("%c", c); //Printing elements in terminal
    }

    printf("The result was written into output.txt\n");
    fclose(fptr2); 
    return 0; 
}