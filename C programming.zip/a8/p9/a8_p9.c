/*
CH-230-A
a8_p9.c
Arlind Kacadej
akacadej@jacobs-university.de
*/

#include <stdio.h> 
#include <string.h>
#include <stdlib.h> // For exit() 
  
int main() { 
    int n, i, counter=0;
    scanf("%d", &n);
    FILE *fptr1, *fptr2; 
    char filename[20], buffer[64], c; 
    fptr2 = fopen("output.txt", "wb"); 
    for(i=0; i<n; i++){
        scanf("%s", filename);
        getchar();
        fptr1 = fopen(filename, "rb"); 
        if (fptr1 == NULL) { 
            printf("Cannot open file %s \n", filename); 
            exit(1); 
        }

        while (getc(fptr1) != EOF) { 
            counter++; 
        } 
        fseek(fptr1, 0, SEEK_SET);
        
        // Read contents from file  
        printf("%d\n", counter);
        fread(buffer, 1, counter, fptr1);
        
        fwrite(buffer, counter, 1, fptr2);
        if(i!=n-1){
            fputc('\n', fptr2);
            printf("sth\n");
        }
        
        counter = 0;
        fclose(fptr1);  
    } 
    fclose(fptr2);
    
    printf("Concating the content of 3 files ...\n");
    fptr2 = fopen("output.txt", "r");
    while ((c= getc(fptr2)) != EOF) { 
        printf ("%c", c); //Printing elements in terminal
    }

    printf("The result was written into output.txt\n");
    fclose(fptr2); 
    return 0; 
}