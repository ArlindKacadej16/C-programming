/*
CH-230-A
a8_p4.c
Arlind Kacadej
akacadej@jacobs-university.de
*/

#include <stdio.h>
#include <stdlib.h>
#include "stack.h"


int main() {
    unsigned int n;
    
    st *s = (st *)malloc(sizeof(st));    
    createEmptyStack(s);
    scanf("%u", &n);
    printf("The binary represantation of %d is ", n);
    int n1;
	while(n>0){
		n1 = (int)n%2;
    	push(s, n1);
    	n = n/2;
	}
	empty(s);
	
	printf("\n");
	return 0;
}