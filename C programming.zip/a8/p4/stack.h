#ifndef LINKED_LIST_H
#define LINKED_LIST_H
#define MAX 50
struct stack{
  unsigned int count;
  int array[MAX];//container
};
typedef struct stack st;

void createEmptyStack(st *s);
int isfull(st *s);
int isempty(st *s);
void push(st *s, int newitem);
void pop(st *s);
void empty(st *s);
void binary(unsigned int n);
void print(st *s);
#endif