/*
CH-230-A
a8_p6.c
Arlind Kacadej
akacadej@jacobs-university.de
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX 20
int main()
{
    double n1, n2, sum, diff, prod, div;
    FILE *filePointer, *fp, *fileP;
    char file1[MAX];
    char file2[MAX];
    
    fgets(file1, MAX, stdin);
    fgets(file2, MAX, stdin);
    
    file1[strlen(file1)-1]='\0';
    file2[strlen(file2)-1]='\0';

    filePointer = fopen(file1, "r");
    fp = fopen(file2, "r");
    // Opens the file where the chars are stored
    if (filePointer == NULL){
        printf("File is not available \n");
        exit(1);
    }
    
    // Opens the file where the chars are stored
    if (fp == NULL){
        printf("File is not available \n");
        exit(1);
    }
    
    fscanf(filePointer, "%lf", &n1);
    fscanf(fp, "%lf", &n2);
    
    sum = n1 + n2;
    diff = n1 - n2;
    prod = n1 * n2;
    div = n1 / n2;

    fileP = fopen("results.txt", "w");
    if (fileP == NULL){
        printf("File is not available \n");
        exit(1);
    }

    fprintf(fileP, "%lf\n", sum); 
    fprintf(fileP, "%lf\n", diff); 
    fprintf(fileP, "%lf\n", prod); 
    fprintf(fileP, "%lf\n", div); 

    fclose(filePointer);
    fclose(fp);
    fclose(fileP);

    return 0;
}