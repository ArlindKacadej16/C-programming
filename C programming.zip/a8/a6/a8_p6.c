/*
CH-230-A
a8_p6.c
Arlind Kacadej
akacadej@jacobs-university.de
*/

#include <stdio.h>
#include <stdlib.h>
#define MAX 20
int main()
{
    double n, n1, n2, sum, diff, prod, div;
    char name1[MAX], name2[MAX];
    fgets(name1, MAX, stdin);
    fgets(name2, MAX, stdin);

    FILE *filePointer, *fp, *FileP;
    //2
    filePointer = fopen(name1, "r");
    // Opens the file where the chars are stored
    //3
    if (filePointer == NULL){
        printf("File is not available \n");
    }
    else{
        //4
        while ((n = fgetc(filePointer)) != EOF){
            n1 = n;
            break;
        }
    }
    
    fp = fopen(name2, "r");
    // Opens the file where the chars are stored
    //3
    if (filePointer == NULL){
        printf("File is not available \n");
    }
    else{
        //4
        while ((n = fgetc(filePointer)) != EOF){
            n2 = n;
            break;
        }
    }

    sum = n1 + n2;
    diff = n1 - n2;
    prod = n1 * n2;
    div = n1 / n2; 
    FileP = fopen("results.txt", "w");

    fprintf(FileP, "%d\n", sum); 
    fprintf(FileP, "%d\n", diff); 
    fprintf(FileP, "%d\n", prod); 
    fprintf(FileP, "%d\n", div); 
    // Prints ASCII sum to file
    //5
    fclose(fp);
    return 0;
}