/**
 * @file queue.c
 */
 
#include <stdio.h>
#include <stdlib.h>
 
#include "queue.h"
 
void initialize_queue(Queue *pq)
{
    pq->front = pq->rear = NULL;
    pq->items = 0;
}
 
int queue_is_full(const Queue *pq)
{
    return pq->items == MAXQUEUE;
}
 
int queue_is_empty(const Queue *pq)
{
    return pq->items == 0;
}
 
int queue_item_count(const Queue *pq)
{
    return pq->items;
}
 
int enqueue(Item item, Queue *pq)
{
    struct node * temp;
 
    temp = (Node*)malloc(sizeof(Node));
    temp->item=item;
    temp->next=NULL;
 
    if(queue_is_empty(pq)==0){
        pq->rear->next=temp;
        pq->rear=temp;
    }else{
        pq->front = temp;
        pq->rear = temp;
    }
    if(queue_is_full(pq)==1){
        return -1;
    }
 
    pq->items++;
    free(temp);
    return 0;
}
 
int dequeue(Item *item, Queue *pq)
{
    struct node * temp;
 
    temp = (Node*)malloc(sizeof(Node));
    if(temp==NULL)
    {
        return -1;
    }
    /*if(new_node->next==NULL){
        pq->front=pq->rear=NULL;
    }*/
    
    *item = pq->front->item;
    temp = pq->front;
    pq->front = pq->front->next;
    
    if(queue_is_empty(pq)==1)
        return -1;
        
    free(temp);
    pq->items--;
    //pq->items = pq->items -1;
    return 0;
}
 
void empty_queue(Queue *pq)
{
    Item dummy;
    while (!queue_is_empty(pq)) {
        dequeue(&dummy, pq);
    }
}

/*void printq(Queue *pq){
	Node * temp;
    temp = pq->front;
    while(temp!=NULL){
        printf("%d ", temp->item);
        temp = temp->next;
    }
    printf("\n");
}*/
