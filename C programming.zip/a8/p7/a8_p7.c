/*
CH-230-A
a8_p7.c
Arlind Kacadej
akacadej@jacobs-university.de
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX 20
int main()
{
    FILE *filePointer, *fp, *fileP;
    char c, file1[MAX], file2[MAX];
    
    file1[strlen(file1)-1]='\0';
    file2[strlen(file2)-1]='\0';

    filePointer = fopen("text1.txt", "r");
    fp = fopen("text2.txt", "r");
    // Opens 1st file where text is stored
    if (filePointer == NULL){
        printf("File is not available \n");
        exit(1);
    }
    
    // Opens 2nd file where text is stored
    if (fp == NULL){
        printf("File is not available \n");
        exit(1);
    }

    fileP = fopen("merge12.txt", "w");
    if (fileP == NULL){
        printf("File is not available \n");
        exit(1);
    }
    while ((c = fgetc(filePointer)) != EOF)
        fputc(c,fileP);

    while ((c = fgetc(fp)) != EOF)
        fputc(c,fileP);

    fclose(filePointer);
    fclose(fp);
    fclose(fileP);

    return 0;
}