/*
CH-230-A
a3_p4.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
int position(char str[], char c){
    int idx=0;
    /* Loop until end of string */
    while(str[idx]!=c && str[idx] != '\0'){
        idx++; 
        //We don't know when the loop ends - while loops are more convenient
    }
 
    if(str[idx]==c){
        return idx;
    }else{
        return -1; /*The program will return -1 
        if char c isn't a character of the string str[]*/
    }
}
 
int main() {
    char line[80];
    while (1) {
        printf("Enter string:\n");
        fgets(line, sizeof(line), stdin);
        printf("The first occurrence of \'g\' is: %d\n", position(line, 'g')); 
    }
}