/*
CH-230-A
a3_p8.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
float sum(int n, float numbers[]){
    float sum = 0;
    int i;
    for(i=0; i<n; i++){
        sum+=numbers[i];
    }
    return sum;
}

float avg(int n, float numbers[]){
    float sum = 0, avg;
    int i;
    for(i=0; i<n; i++){
        sum+=numbers[i];
    }
    avg = sum / n;
    return avg;
}

int main(){
    int n;
    printf("Enter the number of elements: ");
    scanf("%d", &n);
    while(n>10){
        printf("The list cannot have more than 10 numbers - try again: ");
        scanf("%d", &n); //Ensures the number of elements is less then 10
    }

    float numbers[n];
    int idx;
    int unwanted_number=0;
    
    printf("Enter the numbers: \n");
    for(idx = 0; idx < n; idx++){
        scanf("%f", &numbers[idx]); //Takes the numbers as inputs
        if(numbers[idx]==-99.0){
            unwanted_number=1; /*The value of unwanted_number becomes 
            1 when -99.0 appears as an element*/
            break;
       }
    }
    printf("\n");

    if(unwanted_number == 1){ //Checks if -99.0 is a number on the list
        printf("The sum of elements until -99.0 (excluded) is: ");
        printf("%f\n", sum(idx,numbers));
        printf("The average of elements until -99.0 (excluded) is: ");
        printf("%f\n", avg(idx,numbers)); /*Executes the functions if -99.0 
        is an element*/
    }else{
        printf("The sum of elements is: ");
        printf("%f\n", sum(n,numbers));
        printf("The average of elements is: ");
        printf("%f\n", avg(n,numbers)); /*Executes the functions if -99.0 
        is not element*/
    }
}