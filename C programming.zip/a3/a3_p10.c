/*
CH-230-A
a3_p10.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
float product(float a, float b);
void productbyref(float a, float b, float *p);
void modifybyref(float *a, float *b);

int main(){
    float a, b, prd;
    printf("Enter the values for a and b:\n");
    scanf("%f %f", &a, &b); //Taking inputs

    printf("Product = %f\n", product(a,b));
    productbyref(a,b,&prd);
    printf("Product (by Reference) = %f\n", product(a,b));
    modifybyref(&a, &b);
    printf("Modified values (by Reference): a = %f, b = %f\n", a, b);
    printf("Modified product = %f\n", product(a,b)); 
    /*The two last lines return both the modified values
    and their modified product since the problem wasn't clear*/
}

float product(float a, float b){
    return a * b;
}

void productbyref(float a, float b, float *p){
    *p = a * b;;
}

void modifybyref(float *a, float *b){
    *a+=3.0;
    *b+=11.0; //Modifying values
}