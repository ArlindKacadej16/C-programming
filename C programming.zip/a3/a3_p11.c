/*
CH-230-A
a3_p11.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
#include <string.h>
#define MAX_LIMIT 10000

int main(){
	
	int invalid = 1;
    int length1 = MAX_LIMIT, length2 = MAX_LIMIT;
    char one[MAX_LIMIT];
    char two[MAX_LIMIT];
    char character;
    fgets(one, MAX_LIMIT, stdin);
    fgets(two, MAX_LIMIT, stdin);
   
    scanf("%c", &character);
    
 
    char concatenation[MAX_LIMIT]; 
    char copy[length2];
    one[strcspn(one, "\n")] = 0;
    two[strcspn(two, "\n")] = 0; 
    //fgets adds new lines to the input which have to be deleted
 	length1 = strlen(one);
    length2 = strlen(two);
    strcpy(copy, two);
 
    strcpy(concatenation, one);
    strcat(concatenation, two); //Connecting string one and two
 
    printf("length1=%d\n",length1);
    printf("length2=%d\n",length2);
    printf("concatenation=%s\n",concatenation); 
    printf("copy=%s\n", copy);
    
    int result = strcmp(one, two);
    if(result < 0){
        printf("one is smaller than two\n");
    }else if(result > 0){
        printf("one is larger than two\n");
    }else{
        printf("one is equal to two\n");
    }
    
    int idx;
    for(idx = 0; idx < length2; idx++)
	{
		if(two[idx] == character)
		{
			printf("position=%d\n",idx); 
            //Prints position of first appearance of character
			invalid = 0;
			break;
		}
	}
    
    if(invalid == 1){
        printf("The character is not in the string\n");
    }
    return 0; 
}