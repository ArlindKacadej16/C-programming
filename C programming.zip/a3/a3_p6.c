/*
CH-230-A
a3_p6.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
float to_pounds(int kg, int g);

int main(){
    int kg, g;
    scanf("%d", &kg);
    scanf("%d", &g);
    printf("Result of conversion: %f\n", to_pounds(kg, g)); 
    //Printing weight in pounds
}

float to_pounds(int kg, int g){
    double pounds = 2.2*(kg + g/1000.0); /*Converting weight 
    of kg and g into pounds*/
    return pounds;
}