/*
CH-230-A
a3_p3.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
float convert(int cm){
    return cm/100000.0; // 1 cm = 1 km / 100000
}

#include <stdio.h>
int main(){
	int cm; 
    scanf("%d", &cm);
    printf("Result of conversion: %f\n", convert(cm)); 
    //Geting the result of the conversion
	return 0;
}
