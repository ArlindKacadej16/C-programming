/*
CH-230-A
a3_p7.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
void print_form(int n, int m, char c);

int main(){
    int n,m;
    char ch;
    scanf("%d" "%d\n", &n, &m);
    scanf("%c", &ch);
    print_form(n,m,ch); //Executing function
}

void print_form(int n, int m, char c){
    int idx, k;
    for(idx = 0; idx < n; idx++){ //Total nr. of lines=idx
        for(k = 0; k < m+idx; k++){ /*For each line,
        m + idx of the input char are printed*/
            printf("%c", c);  
        }
        printf("\n");//New line at the end of each outer loop
    }
}