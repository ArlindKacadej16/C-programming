/*
CH-230-A
a3_p2.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
int main(){
	char ch;
	int n;

	printf("Enter the lowercase character: ");
	scanf("%c", &ch);
	printf("Enter the value for the integer: ");
	scanf("%d", &n);
	
	printf("%c\n", ch); /*The first line has to be printed separately 
	as it is not of the form: character-i*/
	int i=1;
	while(i<=n){
			printf("%c-%d\n", ch, i); 
			//Every output will be of the form: character - i
			i++; //Incremental of i for each step
	}	
	return 0;
}
