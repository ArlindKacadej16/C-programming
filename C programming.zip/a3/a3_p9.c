/*
CH-230-A
a3_p9.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
double sum25(double v[], int n);

int main(){
    int n;
    scanf("%d", &n);
    while(n>20){
        scanf("%d", &n); //Ensures the nr. of elements < 20
    }
    
    double v[n];
    int i;
    if(n<6){
        printf("One or both positions are invalid\n");
    }else{
        for(i=0; i<n; i++){
            scanf("%lf", &v[i]); //Taking inputs
        }
        printf("sum=%lf\n", sum25(v, n));
    }
}

double sum25(double v[], int n){
    int invalid_case = -111;
    if(n<6){
        return (int)invalid_case;
    }else{
        return v[2] + v[5];
    }
}