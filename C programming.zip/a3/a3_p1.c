/*
CH-230-A
a3_p1.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
 
int main(){
    float x;
    int n;
    scanf("%f", &x);
    scanf("%d", &n);//Taking inputs
    while(n!=(int)n || n<1){
        printf("Input is invalid, reenter value\n"); //Input should be >=1 
        scanf("%d", &n);
    }
    int i = 0;
    while(i<n){
        printf("%f\n", x);
        i++; //Incremental of i for each step
    } 
    return 0;
}
