/*
CH-230-A
a3_p5.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
int main(){
    /* local variable definition */
    char ch;
    int n;

    printf("Enter the character command: ");
    scanf("%c", &ch);
    printf("Enter the number of temperatures: ");
    scanf("%d", &n);

    double c_temperatures[n], f_temperatures[n]; /*Declearing the arrays
    of degrees in Celcius & Farenheit*/
    int i;
    double sum = 0, mean;

    printf("Enter the temperatures:\n");
    for(i=0; i<n; i++){
      scanf("%lf", &c_temperatures[i]); 
      //Taking inputs for temperatures in Celcius
    }
    for(i=0; i<n; i++){
      sum += c_temperatures[i]; //Sum of degrees in Celcius
    }
    for(i=0; i<n; i++){
      f_temperatures[i]=9*c_temperatures[i]/5 +32; 
      //Assigning values to the Farenheit degrees list 
    }
    mean = sum/n;

    switch(ch) {
      case 's' :
        printf("%lf C.", sum);
        break;
        
      case 'p' :
        printf("The temperatures in Celcius:\n");
        for(i=0; i<n; i++){
          printf("%lf C.\n", c_temperatures[i]); 
          //Prints each element of the Celcius list
        }
      break;

      case 't' :
      printf("The temperatures in Farenheit:\n");
        for(i=0; i<n; i++){
          printf("%lf F.\n", f_temperatures[i]); 
          //Prints each element of the Farenheit list
        }
        break;

      default :
        printf("%lf C.", mean);
    }
    return 0;
}