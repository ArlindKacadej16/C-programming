/*
CH-230-A
a5_p11.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
 
void is_prime(int x, int i){
    if(i==1){
        printf("%d is prime\n", x);
    }else if(x==1){
        printf("%d is not prime\n", x); //1 is not prime
    }else{
       if(x%i==0)
        printf("%d is not prime\n", x);
       else
        is_prime(x,i-1); //Recursion
    }
}
 
int main(){
    int x;
    scanf("%d", &x); //Takes number as input
    is_prime(x, x/2);
    return 0;
}