/*
CH-230-A
a5_p9.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void get_matrix(int n, int m, int p){
    int i, j, k;
    int matrix[n][m][p];
    for(i=0; i<n; i++){
        for(j=0; j<m; j++){
            for(k=0; k<p; k++){
                scanf("%d", &matrix[i][j][k]);
                //Takes numbers of matrix A
            }
        }
    }

    
    int *** mat= (int ***) malloc (sizeof(int ***)*p);
        for (j = 0; j < p; j++) {
            mat[j] = (int **) malloc(sizeof(int*)*m);
                for (k = 0; k < m; k++) {
                    mat[j][k] = (int *) malloc(sizeof(int)*n);
        }
    } //Dynamic allocation completed
    
    if (mat == NULL) { 
        exit(0); 
    } 

    for(i=0; i<n; i++){
        for(j=0; j<m; j++){
            for(k=0; k<p; k++){
                mat[i][j][k]=matrix[i][j][k]; /*Assigning values
                to dynamicallly allocated matrix*/
            }
        }
    }

    for(i=0; i<p; i++){
        printf("Section %d:\n", i+1);
        for(j=0; j<m; j++){
            for(k=0; k<n; k++){
                printf("%d ", mat[j][k][i]);
            }
            printf("\n");
        }
    }
    free(mat); //Deallocating
}

int main(){
    int n, m, p;
    scanf("%d", &n);
    scanf("%d", &m);
    scanf("%d", &p);
    
    get_matrix(n,m,p); //Executing function
    return 0;
}