/*
CH-230-A
a5_p5.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>

void scalar_product(double arr1[], double arr2[], int size){
    double product[size], scalarProduct=0;
    int i;
    for(i=0; i<size; i++){
        product[i]=arr1[i] * arr2[i]; 
        scalarProduct= scalarProduct + product[i];
    }
    printf("Scalar product=%lf\n", scalarProduct);
}

void smallest_largest(double arr[], int size){
    int i, j, pos_smallest=0, pos_largest=0;
    
    double smallest = arr[0];
    for(i=0; i<size; i++){
        if(arr[i]<smallest){
            smallest = arr[i];
            pos_smallest = i;
        }
    }
    
    double largest = arr[0];
    for(j=0; j<size; j++){
        if(arr[j]>largest){
            largest = arr[j];
            pos_largest = j;
        }
    }
    printf("The smallest = %lf\n", smallest);
    printf("Position of smallest = %d\n", pos_smallest);
    printf("The largest = %lf\n", largest);
    printf("Position of largest = %d\n", pos_largest);
}

int main(){
    int n;
    scanf("%d", &n); //Taking number of elements
    double numbers1[n];
    double numbers2[n];
    int i;
    
    
    for(i=0; i<n; i++){
        scanf("%lf", &numbers1[i]); //Takes numbers as input
    }

    for(i=0; i<n; i++){
        scanf("%lf", &numbers2[i]); //Takes numbers as input
    }
    
    scalar_product(numbers1, numbers2, n); 
    //Function divides numbers by 5
    smallest_largest(numbers1, n);
    smallest_largest(numbers2, n);
    return 0;
}