/*
CH-230-A
a5_p6.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>

int before_negative(float *arr, int size){
    int i;
    for(i=0; i<size; i++){
        if(*(arr+i)<0){
            break; /*Breaks the loop when the 1st negative
            nr. appears*/
        }
    }
    return i; /*Position of 1st negative nr. ==
    nr. of elements before it*/
}

int main(){
    int n;
    scanf("%d", &n);
    float numbers[n];
    int i;
    for(i=0; i<n; i++){
        scanf("%f", &numbers[i]); //Takes the list of numbers
    }
    
    printf("Before the first negative value: %d\n", 
    before_negative(numbers, n));
    return 0;
}