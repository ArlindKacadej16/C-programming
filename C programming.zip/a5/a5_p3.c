/*
CH-230-A
a5_p3.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
#include <string.h>
#include <ctype.h>
 
int count_lower(char* str){
    int i, counter=0;
    for(i=0; i<strlen(str); i++){
        if((int)*(str+i)<='z' && (int)*(str+i)>='a'){ 
        /*If the character is the same as its lowercase version,
        then it is already lowercase*/
            counter++;
        }
    }
    return counter;
}
 
int main(){
    char string[50], *ptr;
    while(1){
        printf("Enter the string: ");
        fgets(string, 50, stdin);
        ptr = string;
        if(ptr[0]=='\n'){
            break; //Breaks the loop when new line is detected
        }
        printf("The number of lowercase characters is: %d\n", 
        count_lower(ptr));
    }
    return 0;
}