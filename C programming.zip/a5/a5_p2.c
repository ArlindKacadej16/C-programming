/*
CH-230-A
a5_p2.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>

void divby5(float arr[], int size){
    float * ptr=(float*)arr;
    int i;
    for(i=0; i<size; i++){
        *(ptr+i) = arr[i]/5;
    }
}

int main(){
    float numbers[6] = {5.500, 6.500, 7.750, 8.000, 9.600, 10.360};

    printf("Before:\n");
    int i;
    for(i=0; i<6; i++){
        printf("%.3f ", numbers[i]); //.3 precision modifier
    }
    printf("\n");
    
    divby5(numbers, 6); //Functions divides numbers by 5
    printf("After:\n");
    for(i=0; i<6; i++){ 
            printf("%.3f ", numbers[i]); //Prints the modified list       
    }
    printf("\n");
    return 0;
}