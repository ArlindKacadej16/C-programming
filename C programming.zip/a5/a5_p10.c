/*
CH-230-A
a5_p10.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void all_numbers(int n){
    if(n==0){
        exit(0); //Exits function when we reach 0
    }
    printf("%d ", n);
    all_numbers(n-1); //Recusrsion
}
int main(){
    int n;
    printf("Enter the number: ");
    scanf("%d", &n); //Takes number as input
    all_numbers(n);
    return 0;
}