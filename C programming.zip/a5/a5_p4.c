/*
CH-230-A
a5_p4.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
#include <stdlib.h>
void divby5(float arr[], int size){
    float * ptr=(float*)arr;
    int i;
    for(i=0; i<size; i++){
        *(ptr+i) = arr[i]/5;
    }
}

int main(){
    int n;
    printf("Enter the number of elements: ");
    scanf("%d", &n);
    float * ptr = (float*)malloc(n*sizeof(int));
    int i;
    
    if (ptr == NULL) { 
        printf("Memory not allocated.\n"); 
        exit(1); 
    } 
    
        // Memory has been successfully allocated  
        printf("Enter the elements: \n");
        for(i=0; i<n; i++){
            scanf("%f", ptr+i); //Takes numbers as input
        }
        
        printf("Before:\n");
        for(i=0; i<n; i++){
            printf("%.3f ", *(ptr+i));
        }
        printf("\n");
    
        divby5(ptr, n); //Function divides numbers by 5
        printf("After:\n");
        for(i=0; i<n; i++){ 
            printf("%.3f ", *(ptr+i));        
        }
        printf("\n");

    free(ptr); //Deallocates
    return 0;
}