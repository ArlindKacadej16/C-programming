/*
CH-230-A
a5_p1.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>

void figure(int n, char ch){
    int i, j;
    for(i=0; i<n; i++){
        for(j=n-i; j>0; j--){
            printf("%c", ch); //Prints character
        }
        printf("\n"); 
    }
}

int main(){
	int n;
    char ch;
    scanf("%d", &n);
    getchar();
    scanf("%c", &ch);
    //Inputs taken
    figure(n, ch); //Executing function
    return 0;
}