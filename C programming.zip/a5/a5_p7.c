/*
CH-230-A
a5_p7.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(){
    char string1[100];
    char string2[100];
    fgets(string1, 100, stdin);
    fgets(string2, 100, stdin);
    //Strings taken as input
    string1[strlen(string1) - 1] = '\0';
    string2[strlen(string2) - 1] = '\0';
    strcat(string1, string2);
    char *ptr;
    ptr = (char*)malloc(100 * sizeof(char)); 

    if (ptr == NULL) { 
        exit(0); 
    } 
    // Memory has been successfully allocated 

    // Get the elements of the array 
    strcpy(ptr, string1);
    printf("Result of concatenation: %s\n", ptr); 
    free(ptr); //Deallocating
    return 0;
}