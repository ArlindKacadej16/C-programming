/*
CH-230-A
a5_p8.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void get_matrix(int n, int m, int p){
    int i, j, k;

    int **mat1;
    mat1 = (int **)malloc(n * sizeof(int*));
    if (mat1 == NULL) { 
        exit(1); 
    } 
    for(i=0; i<n; i++){
        mat1[i]= (int*) malloc(sizeof(int)*n);
    }

    for(i=0; i<n; i++){
        for(j=0; j<m; j++){
            scanf("%d", &mat1[i][j]);
            //Takes numbers of matrix A
        }
    }

    int **mat2;
    mat2 = (int **)malloc(m * sizeof(int*));
    if (mat2 == NULL) { 
        exit(1); 
    } 
    for(i=0; i<m; i++){
            mat2[i]=(int*)malloc(sizeof(int)*m);
    }

    for(i=0; i<m; i++){
        for(j=0; j<p; j++){
            scanf("%d", &mat2[i][j]);
            //Takes numbers of matrix B
        }
    }

    int **matProd;
    matProd = (int **)malloc(n * p * sizeof(int*));
    if (matProd == NULL) { 
        exit(1); 
    } 
    for(i=0; i<n; i++){
            matProd[i]= (int*)malloc(sizeof(int)*n);
    }
    
    printf("Matrix A:\n");
    for(i=0; i<n; i++){
        for(j=0; j<m; j++){
            printf("%d ", mat1[i][j]); 
            //Prints each element of matrix A
        }
        printf("\n");
    }
    
    printf("Matrix B:\n");
    for(i=0; i<m; i++){
        for(j=0; j<p; j++){
            printf("%d ", mat2[i][j]); 
            //Prints each element of matrix B
        }
        printf("\n");
    }
    
    for(i=0; i<n; i++){
        for(j=0; j<p; j++){
            matProd[i][j]=0;
            for(k=0; k<m; k++){
                matProd[i][j]+=mat1[i][k] * mat2[k][j];
            }
            
        }
    }

    printf("The multiplication result AxB:\n");
    for(i=0; i<n; i++){
        for(j=0; j<p; j++){
            printf("%d ", matProd[i][j]);
            //Prints each element of matrix AxB
        }
        printf("\n");
    }

    for(i=0; i<n; i++){
		free(mat1[i]);
	}
	for(i=0; i<m; i++){
		free(mat2[i]);
	}
	for(i=0; i<n; i++){
		free(matProd[i]);
    }
}

int main(){
    int n, m, p;
    scanf("%d", &n);
    scanf("%d", &m);
    scanf("%d", &p);
    
    get_matrix(n,m,p);
    return 0;
}