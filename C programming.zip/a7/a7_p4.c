/*
CH-230-A
a7_p4.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#define MAX 50

void upper(char string[MAX]){
    int i;
    for(i = 0; i < strlen(string); i++){
        if(isupper(string[i])){
            printf("%c", string[i]);
        }else{
            printf("%c", toupper(string[i]));
        }
    }
} // Turns string into uppercase

void lower(char string[MAX]){
    int i;
    for(i = 0; i < strlen(string); i++){
        if(islower(string[i])){
            printf("%c", string[i]);
        }else{
            printf("%c", tolower(string[i]));
        }
    }
} // Turns string into lowercase

void changeLowerUpper(char string[MAX]){
    int i;
    for(i = 0; i < strlen(string); i++){
        if(islower(string[i])){
            printf("%c", toupper(string[i]));
        }else{
            printf("%c", tolower(string[i]));
        }
    }
}

void exitFunc(char string[MAX]){
        exit(0);
}

int main(){
    char str[MAX], string[MAX];
    fgets(str, MAX, stdin);
    strcpy(string, str); //In order to keep str unchanged
    int n;
    void (*foo_array[4]) (char[]) = {upper, lower, 
    changeLowerUpper, exitFunc};
    
    while(1){
        scanf("%d", &n); //Repeatedly takes character command 
        //(*foo_exit) (n);
        (*foo_array[n-1]) (string);
    }

    printf("\n"); //Newline
    return 0;
}