/*
CH-230-A
a7_p6.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct person {
    char name [30];
    int age;
};

void sortNames(struct person *per, int n){	
    struct person temp;
    int i, j , compareNames, compareAges;

    for(i=0;i<n; i++){
        for(j=0; j <n-1; j++){
            compareNames=strcmp(per[j].name, per[j+1].name);
            compareAges=per[j+1].age - per[j].age;

            if(compareNames>0){ //Returns 1 if per[j].name is before in order
                temp=per[j];
                per[j]=per[j+1];
                per[j+1]=temp;
            } else if(compareNames==0 && compareAges<0) { 
                //Compares ages when words start with the same letter
                temp=per[j];
                per[j]=per[j+1];
                per[j+1]=temp;
            }
        }
    }
}

void sortAges(struct person *per, int n){	
    struct person temp;
    int i, j, compareNames, compareAges;

    for(i=0;i<n; i++){
        for(j=0; j <n-1; j++){
            compareNames=strcmp(per[j].name, per[j+1].name);
            compareAges=per[j+1].age - per[j].age;

            if(compareAges<0){ 
                //If the next age is lower, we change places
                temp=per[j];
                per[j]=per[j+1];
                per[j+1]=temp;
            } else if(compareAges==0 && compareNames>0) {
                //If ages are the same, we sort according to names
                temp=per[j];
                per[j]=per[j+1];
                per[j+1]=temp;
            }
        }
    }
}

void (*bubblesort[2])(struct person *per, int n)={sortNames, sortAges};

int main(){

	int n, i;
	struct person *per;

	scanf("%d", &n);
	getchar();

	per=(struct person *)malloc(sizeof(struct person)*n); //Dynamic allocation

	for(i=0;i<n;i++){
  	    fgets(per[i].name, 30, stdin);
  	    
		per[i].name[strlen(per[i].name)-1]='\0'; //removes new line
		
  	    scanf("%d", &per[i].age);
  	    getchar();
	}

	(*bubblesort[0])(per,n); //Sorts according to names
	
 	for(i=0;i<n;i++){
 	  printf("{%s, %d}; ", per[i].name, per[i].age);
 	}
 	printf("\n");
 
 	(*bubblesort[1])(per,n); //Sorts according to ages
 	
 	for(i=0;i<n;i++){
   		printf("{%s, %d}; ", per[i].name, per[i].age);
 	}
 	printf("\n");

 	free(per); //Deallocating
 	return 0;
}