// A complete working C program to demonstrate all insertion methods 
#include <stdio.h> 
#include <stdlib.h> 
  
// A linked list node 
struct Node { 
    int data; 
    struct Node* next; 
    struct Node* prev; 
}; 
  
/* Given a reference (pointer to pointer) to the head of a list 
   and an int, inserts a new node on the front of the list. */
void push(struct Node** head_ref, int new_data) 
{ 
    /* 1. allocate node */
    struct Node* new_node = (struct Node*)malloc(sizeof(struct Node)); 
  
    /* 2. put in the data  */
    new_node->data = new_data; 
  
    /* 3. Make next of new node as head and previous as NULL */
    new_node->next = (*head_ref); 
    new_node->prev = NULL; 
  
    /* 4. change prev of head node to new node */
    if ((*head_ref) != NULL) 
        (*head_ref)->prev = new_node; 
  
    /* 5. move the head to point to the new node */
    (*head_ref) = new_node; 
} 

void deleteNode(struct Node** head_ref, struct Node* del) 
{ 
    /* base case */
    if (*head_ref == NULL || del == NULL) 
        return; 
  
    /* If node to be deleted is head node */
    if (*head_ref == del) 
        *head_ref = del->next; 
  
    /* Change next only if node to be deleted 
       is NOT the last node */
    if (del->next != NULL) 
        del->next->prev = del->prev; 
  
    /* Change prev only if node to be deleted  
       is NOT the first node */
    if (del->prev != NULL) 
        del->prev->next = del->next; 
  
    /* Finally, free the memory occupied by del*/
    free(del); 
} 
  
void deleteOcurrences(struct Node** head_ref, char x) 
{ 
    
    /* if list is empty */
    if ((*head_ref) == NULL) 
        return; 
  
    struct Node* current = *head_ref; 
    struct Node* next; 
    int counter = 0;
    /* traverse the list up to the end */
    while (current != NULL) { 
  
        /* if node found with the value 'x' */
        if (current->data == x) { 
            counter++;
            /* save current's next node in the  
               pointer 'next' */
            next = current->next; 
  
            /* delete the node pointed to by  
              'current' */
            deleteNode(head_ref, current); 
  
            /* update current */
            current = next; 
            
        } 
  
        /* else simply move to the next node */
        else
            current = current->next; 
    } 
    if(counter == 0){
        printf("The element is not in the list!\n");
    }
} 

// This function prints contents of linked list starting from the given node 
void printForward(struct Node* node) 
{ 
    struct Node* last; 

    while (node != NULL) { 
        printf("%c ", node->data); 
        last = node; 
        node = node->next; 
    } 
    printf("\n");
} 

void printReverse(struct Node* node) 
{ 
    struct Node* last;

    while (last != NULL) { 
        printf("%c ", last->data); 
        last = last->prev; 
    } 
    printf("\n");
} 

void dispose_list (struct Node * head) {
    struct Node * nextelem ;
    while ( head != NULL ) {
        nextelem = head -> next ;
        free ( head );
        head = nextelem ;
    }
    exit(0);
} //Frees struct & exits
  
/* Driver program to test above functions*/
int main() 
{ 
    /* Start with the empty list */
    struct Node* head = NULL; 
    char sub; //Substituting character for case 4
    char c;
    int n;
    while(1){
        scanf("%d", &n); //Repeatedly takes integer command command
        switch(n){
            case 1:
                getchar();
                scanf("%c", &c);
                push(&head, c);
                break;
            case 2:
                scanf("%c", &sub);
                deleteOcurrences(&head, sub);
                /*if (*Node.head) { // Error: no member named 'something' in 'struct.some'
                    strcpy(Node.head, "Hello");*/
                break;
            case 3:
                printForward(head);
                break;    
            case 4:
                printReverse(head);
                break; 
            case 5:
                dispose_list(head);
                break;
        }
    }
    printf("\n");
  
    getchar(); 
    return 0; 
} 