/*
CH-230-A
a7_p2.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
#include <stdlib.h>
#include "linked_list.h"

struct list * my_list = NULL;

int main(){
    char c;
    int n;
    while(1){
        scanf("%c", &c); //Repeatedly takes character command 
        switch(c){
            case 'a':
                scanf("%d", &n);
                my_list = push_back (my_list, n);
                break;
            case 'b':
                scanf("%d", &n);
                my_list = push_front (my_list, n);
                break;
            case 'r':
                    my_list = remove_first(my_list);
                    break;
            case 'p':
                print_list(my_list);
                break;
            case 'q':
                dispose_list(my_list);
                break;
        }
    }
    printf("\n"); //Newline
    return 0;
}