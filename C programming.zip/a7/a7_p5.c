/*
CH-230-A
a7_p5.c
Arlind Kacadej
akacadej@jacobs-university.de
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int a_compare ( const void *va , const void *vb) {
    const int * a = ( const int *) va;
    const int * b = ( const int *) vb;
    if (*a < *b) return -1;
    else if (*a > *b) return 1;
    else return 0;
} // Compares elements for ascending order

void ascending(int array[], int size){
    int i;
    qsort (array , size, sizeof ( array [0]) , a_compare );
    for (i = 0; i < size; i ++)
        printf ("%d ", array [i]);
}

int d_compare ( const void *va , const void *vb) {
    const int * a = ( const int *) va;
    const int * b = ( const int *) vb;
    if (*a < *b) return 1;
    else if (*a > *b) return -1;
    else return 0;
} // Compare elements for descending order

void descending(int array[], int size){
    int i;
    qsort (array , size , sizeof ( array [0]) , d_compare );
    for (i = 0; i < size; i ++)
        printf ("%d ", array [i]);
}

int main(){
    int n, i;
    char c;
    scanf("%d", &n);
    int numbers[n];
    for(i=0; i<n; i++){
        scanf("%d", &numbers[i]);
    }
    
    void (*foo_array[2]) (int numbers[], int size) = {ascending, descending};
    while(1){
        scanf("%c", &c); //Repeatedly takes character command 
        switch(c){
            case 'a':
                (*foo_array[0]) (numbers, n);
                printf("\n");
                break;
            case 'd':
                (*foo_array[1]) (numbers, n);
                printf("\n");
                break;
            case 'e':
                exit(0);
        }
    }
    printf("\n"); //Newline
    return 0;
}