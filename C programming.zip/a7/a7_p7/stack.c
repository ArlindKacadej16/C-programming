#include <stdio.h>
#include <stdlib.h>
#include "stack.h"
#define MAX 12

int counter = 0;
void createEmptyStack(st *s) {
  s->count = -1;
}
// Check if the stack is full
int isfull(st *s) {
  if (s->count == MAX - 1)
    return 1;
  else
    return 0;
}

// Check if the stack is empty
int isempty(st *s) {
  if (int(s->count) == -1)
    return 1;
  else
    return 0;
}

// Add elements into stack
void push(st *s, int newitem) {	
  if (isfull(s)) {
    printf("Pushing Stack Overflow\n");
  } 
  else {
  	printf("Pushing %d\n", newitem);
    s->count++;
    s->array[s->count] = newitem;
  }
  counter++;
}

// Remove element from stack
void pop(st *s) {
  if (isempty(s)) {
    printf("Popping Stack Underflow\n");
  } else {
    printf("Popping %d\n", s->array[s->count]);
    s->count--;
  }
  counter--;
}

//empties the stack by continuosly poping the elements
void empty(st *s) {	
	printf("Emptying Stack ");
  while(isempty(s)!=1) {
	printf("%d ", s->array[s->count]);
    s->count--;
  } 
	printf("\n");
  counter--;
}
