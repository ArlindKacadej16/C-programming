/*
CH-230-A
a7_p7.c
Arlind Kacadej
akacadej@jacobs-university.de
*/

#include <stdio.h>
#include <stdlib.h>
#include "stack.h"


int main() {
    char c;
    int n;
    
    st *s = (st *)malloc(sizeof(st));    
    createEmptyStack(s);

    while(1){
      scanf("%c", &c); //Takes command
      switch(c){
          case 's':
            scanf("%d", &n);
            push(s, n);
            break;
          case 'p':
            pop(s);
            break;
          case 'e':    
            empty(s);
            break;
          case 'q':
            printf("Quit\n");
            exit(0);
      }
    }
}
