#ifndef LINKED_LIST_H
#define LINKED_LIST_H

struct stack{
  unsigned int count;
  int array[12];//container
};
typedef struct stack st;

void createEmptyStack(st *s);
int isfull(st *s);
int isempty(st *s);
void push(st *s, int newitem);
void pop(st *s);
void empty(st *s);

#endif